sap.ui.define([
    'sap/ui/demo/cart/test/unit/model/formatter',
    'sap/ui/demo/cart/test/unit/model/LocalStorageModel',
    'sap/ui/demo/cart/test/unit/model/models'
], function () {
    'use strict';
});

sap.ui.define(['sap/ui/test/Opa5'], function (Opa5) {
	"use strict";

	return Opa5.extend("sap.ui.demo.cart.test.arrangement.DeleteProductJourneyArrangement", {
		iStartMyApp : function (sAdditionalUrlParameters) {
			sAdditionalUrlParameters = sAdditionalUrlParameters || "";
			return this.iStartMyAppInAFrame(jQuery.sap.getResourcePath('sap/ui/demo/cart/test', '/mockserver.html?sap-ui-language=en&sap-ui-animation=false&serverDelay=0' + sAdditionalUrlParameters));
		}
	});
});